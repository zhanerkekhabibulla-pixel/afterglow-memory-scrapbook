import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Shell, btnGhost } from "@/components/afterglow/Shell";
import { MemoryAlbum } from "@/components/afterglow/MemoryAlbum";
import { MusicCard } from "@/components/afterglow/MusicCard";
import { moods } from "@/lib/afterglow/theme";
import { deleteMemory, useMemories } from "@/lib/afterglow/store";

export const Route = createFileRoute("/album/$id")({
  head: () => ({ meta: [
    { title: "Альбом — AFTERGLOW" },
    { name: "description", content: "Разворот воспоминания с фото, историей и музыкой." },
    { property: "og:title", content: "Альбом — AFTERGLOW" },
    { property: "og:description", content: "Страница цифрового скрапбука." },
  ] }),
  component: Album,
});

function Album() {
  const { id } = Route.useParams();
  const list = useMemories();
  // Editing a memory moves it in storage; keep album pages in creation order.
  const memories = [...(list ?? [])].sort((a, b) => b.createdAt - a.createdAt || a.id.localeCompare(b.id));
  const m = memories.find((memory) => memory.id === id);
  const nav = useNavigate();
  if (!m) return <Shell title="Album" back="/">{list === null ? "…" : "Не найдено"}</Shell>;
  return (
    <Shell title={m.title || "Album"} back="/" action={<Link to="/editor/$id" params={{ id }} className="text-sm">Править</Link>}>
      <MemoryAlbum memories={memories} currentId={id} onNavigate={(nextId) => { void nav({ to: "/album/$id", params: { id: nextId }, replace: true, resetScroll: false }); }} />
      <div className="mt-6 space-y-3">
        <div className="text-xs tracking-widest text-muted-foreground">{m.date} · {moods[m.mood].label.toUpperCase()}</div>
        {m.story && <p className="font-serif leading-relaxed">{m.story}</p>}
        {m.details && <p className="text-muted-foreground">{m.details}</p>}
        {m.music && <div className="h-16"><MusicCard music={m.music} /></div>}
        <button className={btnGhost} onClick={() => { if (confirm("Удалить?")) { deleteMemory(id); nav({ to: "/" }); } }}>Удалить</button>
      </div>
    </Shell>
  );
}
