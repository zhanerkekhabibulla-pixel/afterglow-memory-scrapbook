import { useRef, useState } from "react";
import type { Memory } from "@/lib/afterglow/types";
import { PageCanvas } from "./PageCanvas";
import { btnGhost } from "./Shell";

export function MemoryAlbum({ memories, currentId, onNavigate }: {
  memories: Memory[];
  currentId: string;
  onNavigate: (id: string) => void;
}) {
  const index = memories.findIndex((memory) => memory.id === currentId);
  const memory = memories[index];
  const [direction, setDirection] = useState("next");
  const gesture = useRef<{ x: number; y: number; id: number } | null>(null);
  const swiped = useRef(false);

  function turn(step: number) {
    const next = memories[index + step];
    if (!next) return;
    setDirection(step > 0 ? "next" : "previous");
    onNavigate(next.id);
  }

  if (!memory) return null;

  return (
    <section
      aria-label="Альбом воспоминаний"
      aria-roledescription="карусель"
      tabIndex={0}
      className="memory-album rounded-sm focus-visible:outline-2 focus-visible:outline-offset-8 focus-visible:outline-ring"
      onKeyDown={(event) => {
        if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        if ((event.target as HTMLElement).closest("input, textarea, select, [contenteditable=true]")) return;
        if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
          event.preventDefault();
          turn(event.key === "ArrowRight" ? 1 : -1);
        }
      }}
    >
      <div
        className="album-book"
        onPointerDown={(event) => {
          swiped.current = false;
          if (event.pointerType === "mouse" || !event.isPrimary) return;
          gesture.current = { x: event.clientX, y: event.clientY, id: event.pointerId };
        }}
        onPointerUp={(event) => {
          const start = gesture.current;
          gesture.current = null;
          if (!start || start.id !== event.pointerId) return;
          const dx = event.clientX - start.x;
          const dy = event.clientY - start.y;
          if (Math.abs(dx) >= 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
            swiped.current = true;
            turn(dx < 0 ? 1 : -1);
          }
        }}
        onPointerCancel={() => { gesture.current = null; }}
        onClickCapture={(event) => {
          if (swiped.current) {
            event.preventDefault();
            event.stopPropagation();
            swiped.current = false;
          }
        }}
      >
        <div key={memory.id} className={`album-page album-page--${direction}`} role="group" aria-roledescription="страница" aria-label={`${index + 1} из ${memories.length}: ${memory.title}`}>
          <PageCanvas memory={memory} linkPhotos />
          <div className="album-binding" aria-hidden="true" />
        </div>
      </div>
      <nav aria-label="Перелистывание альбома" className="mt-5 flex items-center justify-between gap-3">
        <button type="button" className={`${btnGhost} min-h-11 disabled:cursor-default disabled:opacity-40`} disabled={index === 0} onClick={() => turn(-1)} aria-label="Предыдущая страница">Назад</button>
        <p className="text-center text-sm text-muted-foreground" aria-live="polite" aria-atomic="true">Страница {index + 1} из {memories.length}</p>
        <button type="button" className={`${btnGhost} min-h-11 disabled:cursor-default disabled:opacity-40`} disabled={index === memories.length - 1} onClick={() => turn(1)} aria-label="Следующая страница">Далее</button>
      </nav>
      <p className="mt-3 text-center text-sm text-muted-foreground">
        {memories.length > 1 ? "Листайте свайпом, кнопками или клавишами ← →." : "Пока здесь одна страница. Создайте ещё воспоминание, чтобы листать альбом."}
        <br />Нажмите на фото, чтобы прочитать заметку на обороте.
      </p>
    </section>
  );
}
