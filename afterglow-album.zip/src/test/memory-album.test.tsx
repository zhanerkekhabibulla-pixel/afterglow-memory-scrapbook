import { fireEvent, render, screen, cleanup } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MemoryAlbum } from "@/components/afterglow/MemoryAlbum";
import { demoMemories } from "@/lib/afterglow/demo";

vi.mock("@/components/afterglow/PageCanvas", () => ({
  PageCanvas: ({ memory }: { memory: { title: string } }) => <a href="#photo">{memory.title}</a>,
}));
afterEach(cleanup);

const memories = [0, 1, 2].map((i) => ({ ...demoMemories[0]!, id: `page-${i}`, title: `Коллаж ${i}` }));

describe("Memory album", () => {
  it("turns pages and disables navigation at both ends", () => {
    const onNavigate = vi.fn();
    const { rerender } = render(<MemoryAlbum memories={memories} currentId="page-0" onNavigate={onNavigate} />);
    expect(screen.getByRole("button", { name: "Предыдущая страница" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "Следующая страница" }));
    expect(onNavigate).toHaveBeenLastCalledWith("page-1");
    rerender(<MemoryAlbum memories={memories} currentId="page-2" onNavigate={onNavigate} />);
    expect(screen.getByText("Страница 3 из 3")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Следующая страница" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "Предыдущая страница" }));
    expect(onNavigate).toHaveBeenLastCalledWith("page-1");
  });

  it("supports keyboard navigation without wrapping", () => {
    const onNavigate = vi.fn();
    render(<MemoryAlbum memories={memories} currentId="page-0" onNavigate={onNavigate} />);
    const album = screen.getByRole("region", { name: "Альбом воспоминаний" });
    fireEvent.keyDown(album, { key: "ArrowLeft" });
    expect(onNavigate).not.toHaveBeenCalled();
    fireEvent.keyDown(album, { key: "ArrowRight" });
    expect(onNavigate).toHaveBeenCalledWith("page-1");
  });

  it("handles a single page and a missing page", () => {
    const { rerender } = render(<MemoryAlbum memories={memories.slice(0, 1)} currentId="page-0" onNavigate={vi.fn()} />);
    screen.getAllByRole("button").forEach((button) => expect(button).toBeDisabled());
    expect(screen.getByText(/Пока здесь одна страница/)).toBeInTheDocument();
    rerender(<MemoryAlbum memories={[]} currentId="missing" onNavigate={vi.fn()} />);
    expect(screen.queryByRole("region")).not.toBeInTheDocument();
  });

  it("turns on a horizontal swipe, suppresses its photo click, and allows vertical scrolling", () => {
    const onNavigate = vi.fn();
    render(<MemoryAlbum memories={memories} currentId="page-1" onNavigate={onNavigate} />);
    const photo = screen.getByRole("link");
    function pointer(type: string, x: number, y: number) {
      const event = new Event(type, { bubbles: true });
      Object.assign(event, { clientX: x, clientY: y, pointerId: 1, pointerType: "touch", isPrimary: true });
      fireEvent(photo, event);
    }
    pointer("pointerdown", 200, 100);
    pointer("pointerup", 100, 110);
    expect(onNavigate).toHaveBeenLastCalledWith("page-2");
    expect(fireEvent.click(photo)).toBe(false);
    onNavigate.mockClear();
    pointer("pointerdown", 200, 100);
    pointer("pointerup", 190, 250);
    expect(onNavigate).not.toHaveBeenCalled();
    expect(fireEvent.click(photo)).toBe(true);
  });
});
